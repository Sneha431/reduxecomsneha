import React from 'react'

const notfound = () => {
  return (
    <h1>
      not found
    </h1>
  )
}

export default notfound
