import { useRouter } from 'next/router';
import React from 'react'

const BlogSlug = () => {
  const { query } = useRouter();
  return (
    <div>
      <h1>This is the {query.blog_slug}</h1>
    </div>
  )
}

export default BlogSlug;
