import React from 'react'

const dummy = () => {
  return (
    <div>
      dummy
    </div>
  )
}

export default dummy
