import { useEffect, useState } from "react";
import Navbar from "./components/Navbar"
import { FiPlus, FiSearch } from "react-icons/fi";
import { HiOutlineUserCircle } from "react-icons/hi";
import { collection, getDocs } from "firebase/firestore";
import { db } from "./config/firebase";
import { RiEditCircleLine } from "react-icons/ri";
import { IoMdTrash } from "react-icons/io";
const App = () => {
  const [contacts, setcontact] = useState([]);
  useEffect(() => {
    const getcontacts = async () => {
      try {
        const contactsRef = collection(db, "contacts");
        const contactSnapshot = await getDocs(contactsRef);
        const contactList = contactSnapshot.docs.map((item) => ({ ...item.data(), id: item.id }));
        console.log(contactList);
        setcontact(contactList);
      }
      catch (error) {
        console.log(error);
      }
    }
    getcontacts();

  }, [])

  return (
    <div className="max-w-[400px] mx-auto px-4">
      <div>
        <Navbar />
        <div className="flex relative items-center mx-4">
          <FiSearch className="text-white text-3xl absolute ml-1" />
          <input type="text" className="bg-transparent border border-white rounded-md h-10 flex-grow text-white pl-9 text-lg" />
          <button className="bg-white rounded-3xl ml-2  text-5xl"><FiPlus className="  text-black" /></button>
        </div>

      </div>
      <div className="justify-between text-black flex-col ">



        {contacts.map((contact) =>
        (<div key={contact.id} className="flex text-black justify-between  items-center bg-yellow m-2 p-[px] h-[67px] rounded-md">

          <div className=" text-orange text-4xl w-13 p-2"><HiOutlineUserCircle /></div>
          <div className="absolute ml-12 text-lg items-center flex-grow w-1/6 p-2">{contact.name}<p>{contact.email}</p></div>

          <div className="flex m-2"> <RiEditCircleLine className="text-2xl  ml-1 text-black" />
            <IoMdTrash className="text-2xl  ml-1  text-orange" /></div>


        </div>
        )
        )}


      </div>

    </div >
  )
}

export default App
